# Coolify Configuration 

## Static build (SPA)

- Set `Build Pack` to `nixpacks`.
- Enable `Is it a static site?`.
- Set `Output Directory` to `out`.
- That's all.
