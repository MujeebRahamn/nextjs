# Coolify Configuration 

## Server build (NodeJS) with Prisma
- Set `Build Pack` to `nixpacks`.
- That's all.
