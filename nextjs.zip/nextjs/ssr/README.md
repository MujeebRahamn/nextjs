# Coolify Configuration 

## Server build (NodeJS)
- Set `Build Pack` to `nixpacks`.
- That's all.
